export interface Book{
  bid: string;
  btitle: string;
  imageUrl: string;
  authors: string[];
}
